#include "kernel/types.h"
#include "kernel/stat.h"
#include "user/user.h"

void
work(int n)
{
  volatile int i;
  for(i = 0; i < n; i++){
    ;
  }
}

int
main(void)
{
  int pid;

  printf("FCFS Test Started\n");

  for(int i = 0; i < 3; i++){
    pid = fork();

    if(pid == 0){
      int mypid = getpid();

      printf("Process %d started\n", mypid);

      work(50000000);

      printf("Process %d completed\n", mypid);
      exit(0);
    }

    // Small delay before next fork
    work(1000000);
  }

  // Parent waits for all children
  for(int i = 0; i < 3; i++)
    wait(0);

  printf("FCFS Test Finished\n");

  exit(0);
}
