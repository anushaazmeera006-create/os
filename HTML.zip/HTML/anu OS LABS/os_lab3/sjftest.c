#include "kernel/types.h"
#include "kernel/stat.h"
#include "user/user.h"

void
work(int n)
{
  volatile int i;

  for(i = 0; i < n; i++)
    ;
}

void
worker(int bt, int id)
{
  int pid = getpid();

  if(set_burst(pid, bt) < 0){
    printf("Process %d: set_burst failed\n", id);
    exit(1);
  }

  printf("Process %d ready with burst time %d\n", id, bt);

  // Wait so all children can be created and set their burst times.
  pause(20);

  printf("Process %d started with burst time %d\n", id, bt);

  work(50000000);

  printf("Process %d completed\n", id);

  exit(0);
}

int
main(void)
{
  int pid;

  printf("SJF Test Started\n");

  pid = fork();
  if(pid == 0)
    worker(40, 1);

  pid = fork();
  if(pid == 0)
    worker(20, 2);

  pid = fork();
  if(pid == 0)
    worker(10, 3);

  pid = fork();
  if(pid == 0)
    worker(30, 4);

  wait(0);
  wait(0);
  wait(0);
  wait(0);

  printf("SJF Test Finished\n");
  exit(0);
}
