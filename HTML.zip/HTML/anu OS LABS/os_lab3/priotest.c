#include "kernel/types.h"
#include "kernel/stat.h"
#include "user/user.h"

void
worker(int priority, int id)
{
  setpriority(priority);

  printf("Process %d started with priority %d\n", id, priority);

  // CPU-bound work
  for (volatile int i = 0; i < 50000000; i++)
    ;

  printf("Process %d completed\n", id);
  exit(0);
}

int
main(void)
{
  int pid;

  printf("Priority Test Started\n");

  pid = fork();
  if (pid == 0)
    worker(10, 1);

  pid = fork();
  if (pid == 0)
    worker(5, 2);

  pid = fork();
  if (pid == 0)
    worker(1, 3);

  wait(0);
  wait(0);
  wait(0);

  printf("Priority Test Finished\n");
  exit(0);
}
