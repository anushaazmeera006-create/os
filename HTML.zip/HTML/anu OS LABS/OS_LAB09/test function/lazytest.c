#include "types.h"
#include "stat.h"
#include "user.h"

// Q2: Test lazy allocation and demand-page fault counting.
int
main(void)
{
  char *p;
  int before, after;

  // Read the page-fault count before allocating virtual memory.
  before = getfaults();
  printf(1, "Initial page faults: %d\n", before);

  // Reserve four pages of virtual memory.
  // Physical memory should not be allocated yet.
  p = sbrk(4 * 4096);

  if(p == (char*)-1){
    printf(1, "sbrk failed\n");
    exit();
  }

  // Access the first byte of each page.
  // Each first access should cause one demand-page fault.
  p[0] = 'A';
  p[4096] = 'B';
  p[8192] = 'C';
  p[12288] = 'D';

  // Read the page-fault count after accessing all four pages.
  after = getfaults();

  // Display the number of newly handled page faults.
  printf(1, "New page faults: %d\n", after - before);

  // Verify that all four pages store their written values.
  printf(1, "Values: %c %c %c %c\n",
         p[0], p[4096], p[8192], p[12288]);

  exit();
}
