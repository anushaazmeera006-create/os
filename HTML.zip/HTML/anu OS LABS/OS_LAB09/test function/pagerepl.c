
#include "types.h"
#include "stat.h"
#include "user.h"

#define MAX_REF 50
#define MAX_FRAMES 10

int reference[MAX_REF] = {
  7, 0, 1, 2, 0, 3, 0, 4, 2, 3,
  0, 3, 2, 1, 2, 0, 1, 7, 0, 1
};

// Run FIFO or LRU page replacement.
void
run_algorithm(int refs[], int n, int frames, int is_lru)
{
  int memory[MAX_FRAMES];
  int last_used[MAX_FRAMES];
  int next = 0;
  int faults = 0;
  int hits = 0;
  int i, j, found, victim;

  for(i = 0; i < frames; i++){
    memory[i] = -1;
    last_used[i] = -1;
  }

  printf(1, "\n%s with %d frames\n",
         is_lru ? "LRU" : "FIFO", frames);
  printf(1, "Reference\tFrames\t\tResult\n");

  for(i = 0; i < n; i++){
    found = -1;

    for(j = 0; j < frames; j++){
      if(memory[j] == refs[i]){
        found = j;
        break;
      }
    }

    if(found != -1){
      hits++;
      last_used[found] = i;
      printf(1, "%d\t\t", refs[i]);
      for(j = 0; j < frames; j++)
        printf(1, "%d ", memory[j]);
      printf(1, "\tHIT\n");
    }
    else{
      faults++;

      if(is_lru){
        victim = 0;
        for(j = 1; j < frames; j++){
          if(memory[j] == -1 ||
             (memory[victim] != -1 &&
              last_used[j] < last_used[victim]))
            victim = j;
        }
      }
      else{
        victim = next;
        next = (next + 1) % frames;
      }

      memory[victim] = refs[i];
      last_used[victim] = i;

      printf(1, "%d\t\t", refs[i]);
      for(j = 0; j < frames; j++)
        printf(1, "%d ", memory[j]);
      printf(1, "\tFAULT\n");
    }
  }

  printf(1, "Page faults: %d\n", faults);
  printf(1, "Hits: %d\n", hits);
  printf(1, "Hit ratio: %d%%\n", (hits * 100) / n);
}

// Compare FIFO and LRU for 3, 4 and 5 frames.
int
main(void)
{
  int frames;

  printf(1, "Page Replacement Algorithm Comparison\n");
  printf(1, "Reference string: ");
  for(int i = 0; i < 20; i++)
    printf(1, "%d ", reference[i]);
  printf(1, "\n");

  for(frames = 3; frames <= 5; frames++){
    run_algorithm(reference, 20, frames, 0);
    run_algorithm(reference, 20, frames, 1);
  }

  exit();
}
