#include "types.h"
#include "stat.h"
#include "user.h"

int
main(void)
{
  char *p;

  printf(1, "\n--- Page table before allocation ---\n");
  vmprint();

  p = sbrk(4 * 4096);
  if(p == (char*)-1){
    printf(1, "sbrk failed\n");
    exit();
  }

  // Touch each new page so its mapping is established.
  p[0] = 1;
  p[4096] = 1;
  p[2 * 4096] = 1;
  p[3 * 4096] = 1;

  printf(1, "\n--- Page table after allocating four pages ---\n");
  vmprint();

  exit();
}
