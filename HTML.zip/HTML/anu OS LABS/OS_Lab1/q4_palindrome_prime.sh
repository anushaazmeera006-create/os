#!/bin/bash

# Function to check palindrome
is_palindrome()
{
    value=$1
    reverse=$(echo "$value" | rev)

    if [ "$value" = "$reverse" ]
    then
        echo "$value is a Palindrome"
    else
        echo "$value is not a Palindrome"
    fi
}


is_prime()
{
    number=$1

    if [ $number -le 1 ]
    then
        echo "$number is not a Prime number"
        return
    fi

    for ((i=2; i*i<=number; i++))
    do
        if [ $((number % i)) -eq 0 ]
        then
            echo "$number is not a Prime number"
            return
        fi
    done

    echo "$number is a Prime number"
}


echo "Enter a value:"
read input

is_palindrome "$input"


if [[ "$input" =~ ^[0-9]+$ ]]
then
    is_prime "$input"
fi
