#!/bin/bash

# Simple Interest Calculator


if [ $# -ne 3 ]
then
    echo "Usage: $0 Principal Rate Time"
    exit 1
fi

principal=$1
rate=$2
time=$3

# simple interest
interest=$(echo "($principal * $rate * $time) / 100" | bc)

# total amount
amount=$(echo "$principal + $interest" | bc)

echo "Simple Interest = $interest"
echo "Total Amount = $amount"
