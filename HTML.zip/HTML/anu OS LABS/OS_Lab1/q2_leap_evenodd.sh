#!/bin/bash

#  Leap Year

echo "Enter a year:"
read year

if [ $((year % 400)) -eq 0 ]
then
    echo "$year is a Leap Year"
elif [ $((year % 100)) -eq 0 ]
then
    echo "$year is not a Leap Year"
elif [ $((year % 4)) -eq 0 ]
then
    echo "$year is a Leap Year"
else
    echo "$year is not a Leap Year"
fi



echo "Enter a number:"
read number

#  even or odd
if [ $((number % 2)) -eq 0 ]
then
    echo "$number is Even"
else
    echo "$number is Odd"
fi

# positive, negative or zero
if [ $number -gt 0 ]
then
    echo "$number is Positive"
elif [ $number -lt 0 ]
then
    echo "$number is Negative"
else
    echo "$number is Zero"
fi
