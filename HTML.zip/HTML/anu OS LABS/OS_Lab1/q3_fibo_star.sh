#!/bin/bash



echo "Enter the value of N:"
read n

# Fibonacci series
first=0
second=1

echo "Fibonacci Series:"

for ((i=1; i<=n; i++))
do
    echo -n "$first "

    next=$((first + second))
    first=$second
    second=$next
done

echo
echo

# Star pattern
echo "Star Pattern:"

for ((row=1; row<=n; row++))
do
    for ((column=1; column<=row; column++))
    do
        echo -n "* "
    done
    echo
done
