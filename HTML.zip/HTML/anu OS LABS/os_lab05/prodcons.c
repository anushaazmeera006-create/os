#include "kernel/types.h"
#include "kernel/stat.h"
#include "user/user.h"

#define BUF_SIZE 5
#define ITEMS 20

struct shared_buffer {
  int buffer[BUF_SIZE];
  int in;
  int out;
  int count;
};

void
producer(struct shared_buffer *s, int empty, int full, int mutex)
{
  for (int item = 1; item <= ITEMS; item++) {

    if (s->count == BUF_SIZE)
      printf("Producer: buffer full, waiting...\n");

    sem_wait(empty);
    sem_wait(mutex);

    s->buffer[s->in] = item;
    s->in = (s->in + 1) % BUF_SIZE;
    s->count++;

    printf("Producer: produced %d (count=%d)\n",
           item, s->count);

    sem_signal(mutex);
    sem_signal(full);

  }

  printf("Producer: finished\n");
}

void
consumer(struct shared_buffer *s, int empty, int full, int mutex)
{
  for (int i = 1; i <= ITEMS; i++) {

    if (s->count == 0)
      printf("Consumer: buffer empty, waiting...\n");

    sem_wait(full);
    sem_wait(mutex);

    int item = s->buffer[s->out];

    s->out = (s->out + 1) % BUF_SIZE;
    s->count--;

    printf("Consumer: consumed %d (count=%d)\n",
           item, s->count);

    sem_signal(mutex);
    sem_signal(empty);

  }

  printf("Consumer: finished\n");
}

int
main(void)
{
  struct shared_buffer *s;
  uint64 addr;
  int empty, full, mutex;
  int pid;

  addr = shm_get();

  if (addr == 0) {
    printf("shm_get failed\n");
    exit(1);
  }

  s = (struct shared_buffer *)addr;

  s->in = 0;
  s->out = 0;
  s->count = 0;

  empty = sem_init(BUF_SIZE);
  full = sem_init(0);
  mutex = sem_init(1);

  if (empty < 0 || full < 0 || mutex < 0) {
    printf("semaphore initialization failed\n");
    exit(1);
  }

  pid = fork();

  if (pid < 0) {
    printf("fork failed\n");
    exit(1);
  }

  if (pid == 0) {
    consumer(s, empty, full, mutex);
    exit(0);
  }

  producer(s, empty, full, mutex);

  wait(0);

  printf("Producer-Consumer test completed\n");

  exit(0);
}
