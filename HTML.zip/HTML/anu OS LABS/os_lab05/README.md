# Operating Systems Lab Assignment 5
## Process Synchronization using xv6

Roll Number: 2401MC05
Name: Anusha Azmeera

---

## Build and Run

All implementations were done inside the xv6-riscv source tree.

Build xv6 using:

make clean
make

Run xv6 using:

make qemu

Inside the xv6 shell, run each program:

$ peterson
$ prodcons
$ readwrite
$ dining

---

## Q1 - Mutual Exclusion using Peterson's Algorithm

### Design

Peterson's algorithm is used to provide mutual exclusion between a parent
process and one child process.

A shared memory page is provided using the shm_get() system call.
The parent and child access the same physical shared memory page.

The shared data contains:

- flag[2] - indicates whether each process wants to enter the critical section.
- turn - determines which process gets priority.
- counter - shared counter.

The parent and child each perform 10 iterations.

In each iteration, the process:

1. Enters the critical section using Peterson's algorithm.
2. Increments the shared counter.
3. Prints the counter value.
4. Leaves the critical section.
5. Performs a remainder-section delay.

### Expected Result

There are two processes and each performs 10 increments.

Expected final counter:

20

Example:

$ peterson
Process 0 in CS, counter = ...
Process 1 in CS, counter = ...
...
Final counter = 20

The final counter must be exactly 20, showing that mutual exclusion
was correctly achieved.

---

## Q2 - Producer-Consumer using Semaphores

### Design

A fixed-size circular buffer is shared between one producer and one
consumer.

Buffer size:

5

The producer generates items from 1 to 20.

Three semaphores are used:

- empty - counts the number of empty buffer slots.
- full - counts the number of occupied buffer slots.
- mutex - provides mutual exclusion while accessing the buffer.

The producer waits on empty before inserting an item and signals full
after inserting it.

The consumer waits on full before removing an item and signals empty
after removing it.

The shared buffer contains:

- buffer[]
- in
- out
- count

### Expected Result

All items from 1 to 20 must be produced and consumed exactly once.

There must be:

- No lost items.
- No duplicate items.
- No incorrect ordering.
- No buffer overflow or underflow.

Example:

$ prodcons
Producer: produced 1 ...
Consumer: consumed 1 ...
Producer: produced 2 ...
Consumer: consumed 2 ...
...
Producer-Consumer test completed

The final buffer count should be zero.

---

## Q3 - Readers-Writers

### Design

The Readers-Writers problem is implemented using semaphores.

The program creates:

- 3 reader processes.
- 2 writer processes.

All processes share a single integer.

The following synchronization variables are used:

- resource - provides exclusive access to the shared integer.
- read_mutex - protects the read_count variable.
- service - acts as a turnstile to prevent indefinite writer starvation.

Multiple readers are allowed to read the shared value concurrently.

A writer obtains exclusive access to the shared resource, so readers
cannot access the resource while a writer is writing.

Each writer performs 3 write operations.

### Expected Result

There are two writers and each writer performs three increments.

2 x 3 = 6

Expected final shared value:

6

Example:

$ readwrite
Reader PID ...: read value = ...
Writer PID ...: wrote value = ...
...
Readers-Writers test completed
Final shared value = 6

The output demonstrates interleaving of readers and writers while
maintaining synchronization.

---

## Q4 - Dining Philosophers

### Design

Five philosopher processes and five fork semaphores are created.

Each philosopher performs 5 eating cycles.

Each philosopher requires two forks:

- Left fork.
- Right fork.

To avoid deadlock, resource ordering is used.

Each philosopher always acquires the lower-numbered fork first and then
the higher-numbered fork.

After eating, both forks are released.

This ordering eliminates circular wait and prevents deadlock.

### Expected Result

All five philosophers should complete all five eating cycles.

Example:

$ dining
Philosopher 0: eating (cycle 1)
Philosopher 1: eating (cycle 1)
...
Philosopher 4 finished all cycles
Dining Philosophers test completed
All 5 philosophers completed without deadlock

Successful completion of all philosophers demonstrates that the
program does not deadlock.

---

## System Calls Added

The following system calls were added:

shm_get()
sem_init()
sem_wait()
sem_signal()

shm_get() provides a shared memory page that can be accessed by
related processes.

The semaphore implementation maintains a semaphore table and provides
the synchronization required by the producer-consumer, readers-writers,
and dining-philosophers problems.

---

## Main Files

The main user programs are:

user/peterson.c
user/prodcons.c
user/readwrite.c
user/dining.c

Kernel changes for shared memory and semaphores are provided in the
corresponding diff folders.

Output screenshots/logs are stored in:

screenshots/

---

## Summary

Q1: Peterson's Algorithm
- Parent and child process.
- Shared counter.
- Mutual exclusion.

Q2: Producer-Consumer
- Circular buffer of size 5.
- 20 produced and consumed items.
- empty, full and mutex semaphores.

Q3: Readers-Writers
- 3 readers and 2 writers.
- Multiple readers can read concurrently.
- Writers have exclusive access.
- Turnstile prevents indefinite writer starvation.

Q4: Dining Philosophers
- 5 philosophers and 5 forks.
- 5 eating cycles.
- Resource ordering prevents deadlock.

All programs were built and tested using:

make clean
make
make qemu
