#include "kernel/types.h"
#include "kernel/stat.h"
#include "user/user.h"

struct shared_data {
  volatile int flag[2];
  volatile int turn;
  volatile int counter;
};

void
enter_cs(struct shared_data *s, int id)
{
  int other = 1 - id;

  s->flag[id] = 1;
  __sync_synchronize();

  s->turn = other;
  __sync_synchronize();

  while (s->flag[other] && s->turn == other)
    ;
}

void
leave_cs(struct shared_data *s, int id)
{
  __sync_synchronize();
  s->flag[id] = 0;
}

void
delay(void)
{
  for (volatile int i = 0; i < 100000; i++)
    ;
}

int
main(void)
{
  struct shared_data *s;
  int pid;

  s = (struct shared_data *)shm_get();

  if (s == 0) {
    printf("shm_get failed\n");
    exit(1);
  }

  s->flag[0] = 0;
  s->flag[1] = 0;
  s->turn = 0;
  s->counter = 0;

  pid = fork();

  if (pid < 0) {
    printf("fork failed\n");
    exit(1);
  }

  int id = (pid == 0) ? 1 : 0;

  for (int i = 0; i < 10; i++) {
    enter_cs(s, id);

    s->counter++;

    printf("Process %d in CS, counter = %d\n",
           id, s->counter);

    leave_cs(s, id);

    delay();
  }

  if (pid != 0) {
    wait(0);
    printf("Final counter = %d\n", s->counter);
  }

  exit(0);
}

