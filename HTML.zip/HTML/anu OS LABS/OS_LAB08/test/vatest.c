#include "kernel/types.h"
#include "kernel/stat.h"
#include "user/user.h"

int global_value = 123;

static void
show_mapping(char *label, uint64 va)
{
  uint64 pa = va2pa(va);

  if (pa == (uint64)-1)
    printf("%s: va=%p pa=-1\n", label, (void*)va);
  else
    printf("%s: va=%p pa=%p\n", label, (void*)va, (void*)pa);
}

int
main(void)
{
  int local_value = 456;
  char *heap_value = malloc(4096);

  if (heap_value == 0) {
    printf("vatest: malloc failed\n");
    exit(1);
  }

  printf("Q1: virtual-to-physical translation\n");
  show_mapping("global", (uint64)&global_value);
  show_mapping("local", (uint64)&local_value);
  show_mapping("heap", (uint64)heap_value);
  show_mapping("invalid", 0x7fffffff);

  int pid = fork();
  if (pid < 0) {
    printf("vatest: fork failed\n");
    free(heap_value);
    exit(1);
  }

  if (pid == 0) {
    printf("child pid=%d\n", getpid());
    show_mapping("child global", (uint64)&global_value);
    free(heap_value);
    exit(0);
  }

  wait(0);
  printf("parent pid=%d\n", getpid());
  show_mapping("parent global", (uint64)&global_value);


  free(heap_value);
  exit(0);
}
