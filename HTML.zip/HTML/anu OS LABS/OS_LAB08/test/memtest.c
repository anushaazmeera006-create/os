#include "kernel/types.h"
#include "kernel/stat.h"
#include "user/user.h"

// Q2: Prints memory statistics for the calling process.
static void
printmem(char *label)
{
  struct meminfo info;

  if (getmeminfo(&info) < 0) {
    printf("memtest: getmeminfo failed\n");
    exit(1);
  }

  printf("%s: total=%d free=%d user=%d page_tables=%d\n",
         label, (int)info.total_pages, (int)info.free_pages,
         (int)info.user_pages, (int)info.page_table_pages);
}

// Q2: Shows memory use before and after allocation and fork.
int
main(void)
{
  printf("Q2: physical memory statistics\n");
  printmem("before sbrk");

  if (sbrk(4 * 4096) == (char *)-1) {
    printf("memtest: sbrk failed\n");
    exit(1);
  }
  printmem("after sbrk");

  int pid = fork();
  if (pid < 0) {
    printf("memtest: fork failed\n");
    exit(1);
  }

  if (pid == 0) {
    // Q2: Let the child pause while the parent checks memory use.
    pause(20);
    exit(0);
  }

  printmem("parent while child exists");
  wait(0);
  printmem("parent after child reaped");

  exit(0);
}

