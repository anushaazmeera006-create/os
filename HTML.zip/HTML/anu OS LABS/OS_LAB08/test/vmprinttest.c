#include "kernel/types.h"
#include "kernel/stat.h"
#include "user/user.h"

// Q3: Prints address-space pages and the count expected after excluding the guard.
static void
show_user_pages(char *label)
{
  struct meminfo info;

  if (getmeminfo(&info) < 0) {
    printf("vmprinttest: getmeminfo failed\n");
    exit(1);
  }

  printf("%s: sz_pages=%d expected_user_accessible=%d\n",
         label, (int)info.user_pages, (int)info.user_pages - 1);
}

// Q3: Dumps the page table before and after heap changes.
int
main(void)
{
  printf("Q3: page table at startup\n");
  show_user_pages("startup");
  vmprint();

  // Q3: Grow the heap by eight pages before the second dump.
  if (sbrk(8 * 4096) == (char *)-1) {
    printf("vmprinttest: heap growth failed\n");
    exit(1);
  }
  printf("Q3: page table after sbrk growth\n");
  show_user_pages("after growth");
  vmprint();

  // Q3: Shrink the heap by one page before the final dump.
  if (sbrk(-4096) == (char *)-1) {
    printf("vmprinttest: heap shrink failed\n");
    exit(1);
  }
  printf("Q3: page table after sbrk shrink\n");
  show_user_pages("after shrink");
  vmprint();

  exit(0);
}
