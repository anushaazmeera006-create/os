#include "kernel/types.h"
#include "kernel/stat.h"
#include "user/user.h"

void
cpu_bound(int id)
{
  printf("CPU-bound process %d started, PID %d\n", id, getpid());

  while(1) {
    // CPU-intensive work
  }
}

void
io_bound(int id)
{
  int i;

  printf("I/O-bound process %d started, PID %d\n", id, getpid());

  for(i = 0; i < 10; i++) {
    printf("I/O process %d yielding, iteration %d\n", id, i);
    pause(2);
  }

  printf("I/O-bound process %d finished\n", id);
  exit(0);
}

int
main(void)
{
  int pid;
  int i;

  printf("MLFQ Test Started\n");

  // Create CPU-bound processes.
  for(i = 0; i < 2; i++) {
    pid = fork();

    if(pid == 0) {
      cpu_bound(i + 1);
    }
  }

  // Create I/O-bound processes.
  for(i = 0; i < 2; i++) {
    pid = fork();

    if(pid == 0) {
      io_bound(i + 1);
    }
  }

  // Parent waits for I/O-bound children.
  for(i = 0; i < 2; i++)
    wait(0);

  printf("MLFQ Test Finished\n");
  exit(0);
}
