#include "kernel/types.h"
#include "kernel/stat.h"
#include "user/user.h"

// ===== Lab 4 Q1: SRTF Scheduler =====
// CPU-bound workload used to test SRTF scheduling.
void
work(int n)
{
  volatile int i;
  volatile int x = 0;

  for(i = 0; i < n * 1000000; i++)
    x += i % 10;
}

int
main(void)
{
  int pid;

  printf("SRTF Test Started\n");

  // Long job arrives first.
  pid = fork();

  if(pid == 0){
    int mypid = getpid();

    set_burst(mypid, 100);
    printf("Long job started: PID %d, burst 100\n", mypid);

    work(80);

    printf("Long job completed: PID %d\n", mypid);
    exit(0);
  }

  // Small delay so the first process arrives before the next one.
  for(volatile int i = 0; i < 1000000; i++)
    ;

  // Short job arrives later and should preempt the long job.
  pid = fork();

  if(pid == 0){
    int mypid = getpid();

    set_burst(mypid, 10);
    printf("Short job started: PID %d, burst 10\n", mypid);

    work(10);

    printf("Short job completed: PID %d\n", mypid);
    exit(0);
  }

  // Another job arrives later.
  for(volatile int i = 0; i < 1000000; i++)
    ;

  pid = fork();

  if(pid == 0){
    int mypid = getpid();

    set_burst(mypid, 30);
    printf("Medium job started: PID %d, burst 30\n", mypid);

    work(25);

    printf("Medium job completed: PID %d\n", mypid);
    exit(0);
  }

  // Parent waits for all three children.
  wait(0);
  wait(0);
  wait(0);

  printf("SRTF Test Finished\n");

  exit(0);
}
