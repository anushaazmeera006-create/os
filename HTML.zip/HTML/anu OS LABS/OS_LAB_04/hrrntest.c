#include "kernel/types.h"
#include "kernel/stat.h"
#include "user/user.h"

void
run_job(char *name, int burst)
{
  int pid = getpid();

  printf("%s started: PID %d, burst %d\n", name, pid, burst);

  if(set_burst(burst) < 0){
    printf("%s: set_burst failed\n", name);
    exit(1);
  }

  // Consume CPU time.
  for(volatile int i = 0; i < burst * 1000000; i++)
    ;

  printf("%s completed: PID %d\n", name, pid);
  exit(0);
}

int
main(void)
{
  int pid;

  printf("HRRN Test Started\n");

  pid = fork();
  if(pid == 0)
    run_job("Long job", 100);

  pid = fork();
  if(pid == 0)
    run_job("Medium job", 30);

  pid = fork();
  if(pid == 0)
    run_job("Short job", 10);

  wait(0);
  wait(0);
  wait(0);

  printf("HRRN Test Finished\n");
  exit(0);
}

