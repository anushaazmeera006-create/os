#include <stdio.h>
#include <unistd.h>

int main() {
    char *args[] = {"ls", "-l", NULL};

    execvp("ls", args);

    printf("execvp failed\n");

    return 1;
}
