#include <stdio.h>
#include <unistd.h>

int main() {
    execl("/bin/ls", "ls", "-l", (char *)NULL);

    printf("execl failed\n");

    return 1;
}
