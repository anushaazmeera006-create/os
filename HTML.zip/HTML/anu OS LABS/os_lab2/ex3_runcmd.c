#include <stdio.h>
#include <unistd.h>
#include <sys/wait.h>
#include <stdlib.h>

int main(int argc, char *argv[]) {

    if (argc != 3) {
        printf("Incorrect number of arguments\n");
        return 1;
    }

    pid_t pid = fork();

    if (pid < 0) {
        printf("Fork failed\n");
        return 1;
    }

    if (pid == 0) {
        // Child process
        execlp(argv[1], argv[1], argv[2], (char *)NULL);

        // Runs only if exec fails
        printf("Command execution failed\n");
        exit(1);
    }
    else {
        // Parent process
        wait(NULL);
        printf("Command successfully completed\n");
    }

    return 0;
}
