#include <stdio.h>
#include <unistd.h>

int main() {
    execlp("ls", "ls", "-l", (char *)NULL);

    printf("execlp failed\n");

    return 1;
}
